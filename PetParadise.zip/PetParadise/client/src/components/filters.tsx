import { useState } from "react";
import { Check, ChevronsUpDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { cn } from "@/lib/utils";

interface FiltersProps {
  type: "pets" | "products";
  onFilterChange: (category: string) => void;
}

const PET_TYPES = ["Всі", "Собаки", "Коти", "Птахи", "Риби", "Маленькі тварини"];
const PRODUCT_CATEGORIES = ["Всі", "Корм", "Іграшки", "Аксесуари", "Здоров'я", "Догляд"];

export function Filters({ type, onFilterChange }: FiltersProps) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("Всі");

  const options = type === "pets" ? PET_TYPES : PRODUCT_CATEGORIES;

  return (
    <div className="flex items-center space-x-4 mb-6">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            aria-expanded={open}
            className="w-[200px] justify-between"
          >
            {value}
            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[200px] p-0">
          <Command>
            <CommandInput placeholder="Пошук категорії..." />
            <CommandEmpty>Категорію не знайдено.</CommandEmpty>
            <CommandGroup>
              {options.map((option) => (
                <CommandItem
                  key={option}
                  onSelect={(currentValue) => {
                    setValue(currentValue);
                    setOpen(false);
                    onFilterChange(currentValue === "Всі" ? "All" : option);
                  }}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      value === option ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {option}
                </CommandItem>
              ))}
            </CommandGroup>
          </Command>
        </PopoverContent>
      </Popover>
    </div>
  );
}