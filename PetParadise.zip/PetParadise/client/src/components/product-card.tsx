import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { Pet, Product } from "@shared/schema";
import { motion } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

interface ProductCardProps {
  item: Pet | Product;
  type: "pet" | "product";
}

export function ProductCard({ item, type }: ProductCardProps) {
  const { toast } = useToast();

  const addToCart = async () => {
    try {
      await apiRequest("POST", "/api/cart", {
        type,
        itemId: item.id,
        quantity: 1
      });
      toast({
        title: "Додано до кошика",
        description: "Товар успішно додано до вашого кошика"
      });
    } catch (error) {
      toast({
        title: "Помилка",
        description: "Не вдалося додати товар до кошика",
        variant: "destructive"
      });
    }
  };

  return (
    <motion.div whileHover={{ scale: 1.02 }} transition={{ duration: 0.2 }}>
      <Card className="overflow-hidden">
        <Dialog>
          <DialogTrigger className="w-full">
            <div className="aspect-square relative">
              <img
                src={item.imageUrl}
                alt={item.name}
                className="object-cover w-full h-full hover:opacity-90 transition-opacity"
              />
            </div>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{item.name}</DialogTitle>
              <DialogDescription>
                {type === "pet" ? (
                  <>
                    <p className="mt-2"><strong>Порода:</strong> {(item as Pet).breed}</p>
                    <p><strong>Вік:</strong> {(item as Pet).age}</p>
                    <p><strong>Статус:</strong> {(item as Pet).available ? "Доступний" : "Не доступний"}</p>
                  </>
                ) : (
                  <>
                    <p className="mt-2"><strong>Категорія:</strong> {(item as Product).category}</p>
                    <p><strong>В наявності:</strong> {(item as Product).stock} шт.</p>
                  </>
                )}
                <p className="mt-2">{item.description}</p>
                <p className="text-lg font-bold mt-4">Ціна: ${item.price}</p>
              </DialogDescription>
            </DialogHeader>
          </DialogContent>
        </Dialog>

        <CardContent className="p-4">
          <h3 className="font-semibold text-lg">{item.name}</h3>
          <p className="text-sm text-gray-500 mt-1">
            {type === "pet" ? (item as Pet).breed : (item as Product).category}
          </p>
          <p className="text-lg font-bold mt-2">${item.price}</p>
        </CardContent>
        <CardFooter className="p-4 pt-0">
          <Button onClick={addToCart} className="w-full">
            Додати до кошика
          </Button>
        </CardFooter>
      </Card>
    </motion.div>
  );
}