import { Link, useLocation } from "wouter";
import { ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export function Navigation() {
  const [location] = useLocation();

  return (
    <motion.nav 
      className="bg-white shadow-sm sticky top-0 z-50"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link href="/">
              <motion.a 
                className="flex items-center px-2 text-2xl font-bold text-primary"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                PetShop
              </motion.a>
            </Link>

            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <NavLink href="/pets" current={location === "/pets"}>
                Тварини
              </NavLink>
              <NavLink href="/products" current={location === "/products"}>
                Товари
              </NavLink>
            </div>
          </div>

          <div className="flex items-center">
            <Link href="/cart">
              <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                <Button variant="ghost" size="icon">
                  <ShoppingCart className="h-5 w-5" />
                </Button>
              </motion.div>
            </Link>
          </div>
        </div>
      </div>
    </motion.nav>
  );
}

function NavLink({ href, current, children }: { href: string; current: boolean; children: React.ReactNode }) {
  return (
    <Link href={href}>
      <motion.a 
        className={`inline-flex items-center px-1 pt-1 text-sm font-medium border-b-2 ${
          current 
            ? "border-primary text-gray-900"
            : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
        }`}
        whileHover={{ y: -2 }}
        whileTap={{ y: 0 }}
      >
        {children}
      </motion.a>
    </Link>
  );
}