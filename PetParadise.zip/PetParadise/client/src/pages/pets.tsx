import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ProductCard } from "@/components/product-card";
import { Filters } from "@/components/filters";
import type { Pet } from "@shared/schema";
import { motion } from "framer-motion";

const typeMapping: Record<string, string> = {
  "Собаки": "Dog",
  "Коти": "Cat",
  "Птахи": "Bird",
  "Риби": "Fish",
  "Маленькі тварини": "Small Pet"
};

export default function Pets() {
  const [filter, setFilter] = useState("All");

  const { data: pets, isLoading } = useQuery<Pet[]>({
    queryKey: ["/api/pets"]
  });

  const filteredPets = pets?.filter(pet => 
    filter === "All" ? true : pet.type === typeMapping[filter]
  );

  return (
    <motion.div 
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold mb-8">Доступні тварини</h1>

      <Filters type="pets" onFilterChange={setFilter} />

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="h-[400px] bg-gray-100 animate-pulse rounded-lg" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPets?.map((pet) => (
            <motion.div
              key={pet.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <ProductCard key={pet.id} item={pet} type="pet" />
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
}