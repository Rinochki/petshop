import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { CartItem, Pet, Product } from "@shared/schema";

export default function Cart() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: cartItems } = useQuery<CartItem[]>({
    queryKey: ["/api/cart"]
  });

  const { data: pets } = useQuery<Pet[]>({
    queryKey: ["/api/pets"]
  });

  const { data: products } = useQuery<Product[]>({
    queryKey: ["/api/products"]
  });

  const removeItemMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/cart/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
      toast({
        title: "Товар видалено",
        description: "Товар був видалений з вашого кошика"
      });
    }
  });

  const updateQuantityMutation = useMutation({
    mutationFn: async ({ id, quantity }: { id: number; quantity: number }) => {
      await apiRequest("PATCH", `/api/cart/${id}`, { quantity });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    }
  });

  const getItemDetails = (cartItem: CartItem) => {
    if (cartItem.type === "pet") {
      return pets?.find(p => p.id === cartItem.itemId);
    }
    return products?.find(p => p.id === cartItem.itemId);
  };

  const total = cartItems?.reduce((sum, item) => {
    const details = getItemDetails(item);
    return sum + (Number(details?.price) * item.quantity);
  }, 0);

  if (!cartItems?.length) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
        <h1 className="text-3xl font-bold mb-4">Ваш кошик порожній</h1>
        <p className="text-gray-600 mb-8">Додайте деякі товари або тварин, щоб розпочати покупки!</p>
        <Link href="/products">
          <Button>Перейти до магазину</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h1 className="text-3xl font-bold mb-8">Кошик</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          {cartItems.map((item) => {
            const details = getItemDetails(item);
            if (!details) return null;

            return (
              <div key={item.id} className="flex gap-4 p-4 border-b">
                <img
                  src={details.imageUrl}
                  alt={details.name}
                  className="w-24 h-24 object-cover rounded"
                />
                <div className="flex-1">
                  <h3 className="font-semibold">{details.name}</h3>
                  <p className="text-gray-600">${details.price}</p>

                  <div className="flex items-center gap-4 mt-2">
                    <select
                      value={item.quantity}
                      onChange={(e) => updateQuantityMutation.mutate({
                        id: item.id,
                        quantity: Number(e.target.value)
                      })}
                      className="rounded border p-1"
                    >
                      {[1,2,3,4,5].map(n => (
                        <option key={n} value={n}>{n}</option>
                      ))}
                    </select>

                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeItemMutation.mutate(item.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="lg:col-span-1">
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-4">Підсумок замовлення</h3>
            <div className="flex justify-between mb-4">
              <span>Загальна сума</span>
              <span className="font-semibold">${total?.toFixed(2)}</span>
            </div>
            <Link href="/checkout">
              <Button className="w-full">Оформити замовлення</Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}