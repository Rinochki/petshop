import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ProductCard } from "@/components/product-card";
import { Filters } from "@/components/filters";
import type { Product } from "@shared/schema";
import { motion } from "framer-motion";

const categoryMapping: Record<string, string> = {
  "Корм": "Food",
  "Іграшки": "Toys",
  "Аксесуари": "Accessories",
  "Здоров'я": "Health",
  "Догляд": "Grooming"
};

export default function Products() {
  const [filter, setFilter] = useState("All");

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products"]
  });

  const filteredProducts = products?.filter(product => 
    filter === "All" ? true : product.category === categoryMapping[filter]
  );

  return (
    <motion.div 
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold mb-8">Товари для тварин</h1>

      <Filters type="products" onFilterChange={setFilter} />

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(8)].map((_, i) => (
            <div key={i} className="h-[300px] bg-gray-100 animate-pulse rounded-lg" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProducts?.map((product) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <ProductCard key={product.id} item={product} type="product" />
            </motion.div>
          ))}
        </div>
      )}
    </motion.div>
  );
}