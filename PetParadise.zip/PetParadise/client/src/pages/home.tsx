import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { ProductCard } from "@/components/product-card";
import type { Pet, Product } from "@shared/schema";
import { motion } from "framer-motion";

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
};

const item = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0 }
};

export default function Home() {
  const { data: pets } = useQuery<Pet[]>({ 
    queryKey: ["/api/pets"]
  });

  const { data: products } = useQuery<Product[]>({
    queryKey: ["/api/products"]
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <motion.div 
        className="text-center mb-16"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          Ласкаво просимо до PetShop
        </h1>
        <p className="text-xl text-gray-600 mb-8">
          Знайдіть свого ідеального друга та все необхідне для його комфорту
        </p>
        <div className="flex justify-center gap-4">
          <Link href="/pets">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button size="lg">Переглянути тварин</Button>
            </motion.div>
          </Link>
          <Link href="/products">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button size="lg" variant="outline">Магазин товарів</Button>
            </motion.div>
          </Link>
        </div>
      </motion.div>

      {/* Featured Pets */}
      <section className="mb-16">
        <motion.h2 
          className="text-2xl font-bold mb-6"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          Особливі тварини
        </motion.h2>
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={container}
          initial="hidden"
          animate="show"
        >
          {pets?.slice(0, 3).map((pet) => (
            <motion.div key={pet.id} variants={item}>
              <ProductCard item={pet} type="pet" />
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* Featured Products */}
      <section>
        <motion.h2 
          className="text-2xl font-bold mb-6"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          Популярні товари
        </motion.h2>
        <motion.div 
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6"
          variants={container}
          initial="hidden"
          animate="show"
        >
          {products?.slice(0, 4).map((product) => (
            <motion.div key={product.id} variants={item}>
              <ProductCard item={product} type="product" />
            </motion.div>
          ))}
        </motion.div>
      </section>
    </div>
  );
}