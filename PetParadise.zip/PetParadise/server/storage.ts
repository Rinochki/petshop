import { 
  type Pet, type Product, type CartItem,
  type InsertPet, type InsertProduct, type InsertCartItem
} from "@shared/schema";

export interface IStorage {
  // Pets
  getPets(): Promise<Pet[]>;
  getPetById(id: number): Promise<Pet | undefined>;
  createPet(pet: InsertPet): Promise<Pet>;
  updatePet(id: number, pet: Partial<InsertPet>): Promise<Pet | undefined>;

  // Products  
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: Partial<InsertProduct>): Promise<Product | undefined>;

  // Cart
  getCartItems(sessionId: string): Promise<CartItem[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  removeFromCart(id: number): Promise<void>;
  clearCart(sessionId: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private pets: Map<number, Pet>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private currentPetId: number;
  private currentProductId: number;
  private currentCartItemId: number;

  constructor() {
    this.pets = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.currentPetId = 1;
    this.currentProductId = 1;
    this.currentCartItemId = 1;

    // Add some sample data
    this.initSampleData();
  }

  private initSampleData() {
    // Зразки тварин
    const samplePets: InsertPet[] = [
      {
        name: "Макс",
        type: "Dog",
        breed: "Золотистий ретривер",
        age: "2 роки",
        price: "800",
        description: "Дружелюбний та енергійний золотистий ретривер, ідеальний для сім'ї",
        imageUrl: "https://images.unsplash.com/photo-1552053831-71594a27632d",
        available: true
      },
      {
        name: "Луна",
        type: "Cat",
        breed: "Персидська",
        age: "1 рік",
        price: "500",
        description: "Грайлива персидська кішка з ласкавим характером",
        imageUrl: "https://images.unsplash.com/photo-1573865526739-10659fec78a5",
        available: true
      },
      {
        name: "Рокі",
        type: "Dog",
        breed: "Хаскі",
        age: "1.5 роки",
        price: "900",
        description: "Активний та розумний хаскі, любить довгі прогулянки",
        imageUrl: "https://images.unsplash.com/photo-1605568427561-40dd23c2acea",
        available: true
      },
      {
        name: "Мурка",
        type: "Cat",
        breed: "Британська короткошерста",
        age: "8 місяців",
        price: "450",
        description: "Спокійна британська кішка, любить ласку",
        imageUrl: "https://images.unsplash.com/photo-1533743983669-94fa5c4338ec",
        available: true
      },
      {
        name: "Чарлі",
        type: "Bird",
        breed: "Хвилястий папуга",
        age: "6 місяців",
        price: "150",
        description: "Яскравий та балакучий папуга, швидко вчиться",
        imageUrl: "https://images.unsplash.com/photo-1552728089-57bdde30beb3",
        available: true
      }
    ];

    // Зразки товарів
    const sampleProducts: InsertProduct[] = [
      {
        name: "Преміум корм для собак",
        category: "Food",
        price: "29.99",
        description: "Високоякісний корм для собак всіх порід",
        imageUrl: "https://images.unsplash.com/photo-1589924691995-400dc9ecc119",
        stock: 50
      },
      {
        name: "Набір іграшок для котів",
        category: "Toys",
        price: "15.99",
        description: "Інтерактивні іграшки для активних котів",
        imageUrl: "https://images.unsplash.com/photo-1587300003388-59208cc962cb",
        stock: 30
      },
      {
        name: "Комфортний будиночок",
        category: "Accessories",
        price: "49.99",
        description: "Затишний будиночок для домашніх улюбленців",
        imageUrl: "https://images.unsplash.com/photo-1592194996308-7b43878e84a6",
        stock: 20
      },
      {
        name: "Автоматична поїлка",
        category: "Accessories",
        price: "34.99",
        description: "Розумна поїлка з фільтрацією води",
        imageUrl: "https://images.unsplash.com/photo-1581398686280-e25d72194718",
        stock: 25
      },
      {
        name: "Вітаміни для птахів",
        category: "Health",
        price: "12.99",
        description: "Комплекс вітамінів для здоров'я птахів",
        imageUrl: "https://images.unsplash.com/photo-1590419690008-905895e8fe0d",
        stock: 40
      },
      {
        name: "Грумінг набір",
        category: "Grooming",
        price: "45.99",
        description: "Професійний набір для догляду за шерстю",
        imageUrl: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7",
        stock: 15
      }
    ];

    samplePets.forEach(pet => this.createPet(pet));
    sampleProducts.forEach(product => this.createProduct(product));
  }

  // Pet methods
  async getPets(): Promise<Pet[]> {
    return Array.from(this.pets.values());
  }

  async getPetById(id: number): Promise<Pet | undefined> {
    return this.pets.get(id);
  }

  async createPet(pet: InsertPet): Promise<Pet> {
    const id = this.currentPetId++;
    const newPet = { id, ...pet };
    this.pets.set(id, newPet);
    return newPet;
  }

  async updatePet(id: number, update: Partial<InsertPet>): Promise<Pet | undefined> {
    const pet = this.pets.get(id);
    if (!pet) return undefined;
    const updatedPet = { ...pet, ...update };
    this.pets.set(id, updatedPet);
    return updatedPet;
  }

  // Product methods
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.currentProductId++;
    const newProduct = { id, ...product };
    this.products.set(id, newProduct);
    return newProduct;
  }

  async updateProduct(id: number, update: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    const updatedProduct = { ...product, ...update };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  // Cart methods
  async getCartItems(sessionId: string): Promise<CartItem[]> {
    return Array.from(this.cartItems.values())
      .filter(item => item.sessionId === sessionId);
  }

  async addToCart(item: InsertCartItem): Promise<CartItem> {
    const id = this.currentCartItemId++;
    const newItem = { id, ...item };
    this.cartItems.set(id, newItem);
    return newItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const item = this.cartItems.get(id);
    if (!item) return undefined;
    const updatedItem = { ...item, quantity };
    this.cartItems.set(id, updatedItem);
    return updatedItem;
  }

  async removeFromCart(id: number): Promise<void> {
    this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<void> {
    const entries = Array.from(this.cartItems.entries());
    for (const [id, item] of entries) {
      if (item.sessionId === sessionId) {
        this.cartItems.delete(id);
      }
    }
  }
}

export const storage = new MemStorage();