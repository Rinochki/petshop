import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertPetSchema, insertProductSchema, insertCartItemSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Pets routes
  app.get("/api/pets", async (_req, res) => {
    const pets = await storage.getPets();
    res.json(pets);
  });

  app.get("/api/pets/:id", async (req, res) => {
    const pet = await storage.getPetById(Number(req.params.id));
    if (!pet) {
      res.status(404).json({ message: "Pet not found" });
      return;
    }
    res.json(pet);
  });

  // Products routes
  app.get("/api/products", async (_req, res) => {
    const products = await storage.getProducts();
    res.json(products);
  });

  app.get("/api/products/:id", async (req, res) => {
    const product = await storage.getProductById(Number(req.params.id));
    if (!product) {
      res.status(404).json({ message: "Product not found" });
      return;
    }
    res.json(product);
  });

  // Cart routes
  app.get("/api/cart", async (req, res) => {
    const sessionId = req.sessionID;
    const items = await storage.getCartItems(sessionId);
    res.json(items);
  });

  app.post("/api/cart", async (req, res) => {
    try {
      const sessionId = req.sessionID;
      const data = insertCartItemSchema.parse({ ...req.body, sessionId });
      const item = await storage.addToCart(data);
      res.json(item);
    } catch (error) {
      res.status(400).json({ message: "Invalid request data" });
    }
  });

  app.patch("/api/cart/:id", async (req, res) => {
    const item = await storage.updateCartItem(Number(req.params.id), req.body.quantity);
    if (!item) {
      res.status(404).json({ message: "Cart item not found" });
      return;
    }
    res.json(item);
  });

  app.delete("/api/cart/:id", async (req, res) => {
    await storage.removeFromCart(Number(req.params.id));
    res.status(204).end();
  });

  app.delete("/api/cart", async (req, res) => {
    await storage.clearCart(req.sessionID);
    res.status(204).end();
  });

  const httpServer = createServer(app);
  return httpServer;
}
